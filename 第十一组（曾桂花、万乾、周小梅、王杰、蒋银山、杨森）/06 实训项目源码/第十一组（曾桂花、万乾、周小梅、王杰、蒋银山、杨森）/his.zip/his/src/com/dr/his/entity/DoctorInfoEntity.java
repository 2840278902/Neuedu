package com.dr.his.entity;
/**
 * ҽ����Ϣ
 * 
 * **/
public class DoctorInfoEntity {
	private int id;//ҽ�����
	private String zhanghao;//��½�˺�
	private String username;//��ʵ����
	private String inputpwd;//��½����
	private String dep;//�������ұ��
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getZhanghao() {
		return zhanghao;
	}
	public void setZhanghao(String zhanghao) {
		this.zhanghao = zhanghao;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getInputpwd() {
		return inputpwd;
	}
	public void setInputpwd(String inputpwd) {
		this.inputpwd = inputpwd;
	}
	public String getDep() {
		return dep;
	}
	public void setDep(String dep) {
		this.dep = dep;
	}
}
