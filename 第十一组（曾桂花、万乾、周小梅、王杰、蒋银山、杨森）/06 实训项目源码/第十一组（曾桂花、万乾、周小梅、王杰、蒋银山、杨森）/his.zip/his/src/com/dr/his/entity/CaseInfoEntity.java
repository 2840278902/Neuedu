package com.dr.his.entity;
/*
 *  ������ϱ�
 *
 * 
 * */
public class CaseInfoEntity {

	private int id;//���
	private String cNo;//������
	private String cInfo;//�����Ϣ
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getcNo() {
		return cNo;
	}
	public void setcNo(String cNo) {
		this.cNo = cNo;
	}
	public String getcInfo() {
		return cInfo;
	}
	public void setcInfo(String cInfo) {
		this.cInfo = cInfo;
	}
	
	
}
