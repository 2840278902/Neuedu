package com.dr.his.entity;

public class RegisterEntity {

	private int id;//���
	private String caseNo;//������
	private String rname;//����
	private int sex;//�Ա�
	private int age;//����
	private String birthday;//��������
	private int settleType;//�������
	private String mcardNo;//ҽ��֤��
	private int medicalType;//ҽ������
	private String idCard;//����֤
	private String address;//��ͥ��ַ
	private String vistDate;//��������
	private int regLevel;//�Һż���
	private int deptNo;//�Һſ��ұ��
	private int drId;//����ҽ��
	private int regPay;//Ӧ�ս��
	private int regSrc;//�Һ���Դ
	private int diagState;//���״̬
	private int regState;//�Һ�״̬��Ĭ������
	private String invNo;//��Ʊ��
	private String regDate;//�Һ�����
	private String ageType;//��������
	//��չ�ֶΣ����ҳ��
	private String caseInfo;//�����Ϣ
	//��չ�ֶΣ��շ�ҳ��
	private String depName;//��������
	private String userName;//ҽ������
	public String getDepName() {
		return depName;
	}
	public void setDepName(String depName) {
		this.depName = depName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCaseInfo() {
		return caseInfo;
	}
	public void setCaseInfo(String caseInfo) {
		this.caseInfo = caseInfo;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCaseNo() {
		return caseNo;
	}
	public void setCaseNo(String caseNo) {
		this.caseNo = caseNo;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public int getSex() {
		return sex;
	}
	public void setSex(int sex) {
		this.sex = sex;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public int getSettleType() {
		return settleType;
	}
	public void setSettleType(int settleType) {
		this.settleType = settleType;
	}
	public String getMcardNo() {
		return mcardNo;
	}
	public void setMcardNo(String mcardNo) {
		this.mcardNo = mcardNo;
	}
	public int getMedicalType() {
		return medicalType;
	}
	public void setMedicalType(int medicalType) {
		this.medicalType = medicalType;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getVistDate() {
		return vistDate;
	}
	public void setVistDate(String vistDate) {
		this.vistDate = vistDate;
	}
	public int getRegLevel() {
		return regLevel;
	}
	public void setRegLevel(int regLevel) {
		this.regLevel = regLevel;
	}
	public int getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}
	public int getDrId() {
		return drId;
	}
	public void setDrId(int drId) {
		this.drId = drId;
	}
	public int getRegPay() {
		return regPay;
	}
	public void setRegPay(int regPay) {
		this.regPay = regPay;
	}
	public int getRegSrc() {
		return regSrc;
	}
	public void setRegSrc(int regSrc) {
		this.regSrc = regSrc;
	}
	public int getDiagState() {
		return diagState;
	}
	public void setDiagState(int diagState) {
		this.diagState = diagState;
	}
	public int getRegState() {
		return regState;
	}
	public void setRegState(int regState) {
		this.regState = regState;
	}
	public String getInvNo() {
		return invNo;
	}
	public void setInvNo(String invNo) {
		this.invNo = invNo;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getAgeType() {
		return ageType;
	}
	public void setAgeType(String ageType) {
		this.ageType = ageType;
	}
	
	
	
}
